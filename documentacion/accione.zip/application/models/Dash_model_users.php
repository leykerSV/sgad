<?php

class Dash_model_users extends CI_Model
{
    /* FUNCTIONS MVC */
    public function getUsers()
    {
        $this->db->select('users.id, users.name, users.lastname, users.email, users.rol_id, roles.rol');
        $this->db->from('users');
        $this->db->join('roles','roles.id=users.rol_id','Left');
        $this->db->where('users.state', 1);
        $query=$this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return null;
        }
    }
    
    public function getUser($id)
    {
        $this->db->select('users.id, users.name, users.lastname, users.email, users.rol_id, roles.rol');
        $this->db->from('users');
        $this->db->join('roles','roles.id=users.rol_id','Left');
        $this->db->where('users.state', 1);
        $this->db->where('users.id', $id);

        $query=$this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row_array();
        } else {
            return null;
        }
    }

    public function storeUser($data)
    {
        $this->db->set('name', $data['name']);
        $this->db->set('lastname', $data['lastname']);
        $this->db->set('email', $data['email']);
        $this->db->set('password', md5($data['password']));
        $this->db->set('rol_id', $data['rol_id']);
        $this->db->set('state', 1);
        $this->db->insert('users');
        return true;
    }    
    
    public function updateUser($data, $id)
    {
        //$this->db->set($data);
        $this->db->set('name', $data['name']);
        $this->db->set('lastname', $data['lastname']);
        $this->db->set('email', $data['email']);
        //$this->db->set('password', md5($data['password']));
        $this->db->set('rol_id', $data['rol_id']);
        $this->db->where('id', $id);
        $this->db->update('users');
    }
    public function destroyUser($data)
    {
        $this->db->where('id', $data);
        $data = array(
            'state' => '0',
        );
        $this->db->update('users', $data);
        return true;
    }
    
    /* FUNCTIONS ADITIONALS */
    public function getRolesUsers()
    {
        $this->db->select('id, rol');
        $this->db->from('roles');
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return null;
        }
    }

    public function getUsersxLeaders()
    {
        $this->db->select('id, name, lastname');
        $this->db->from('users');
        $this->db->where('rol_id', 2);
        $this->db->where('state', 1);
        $this->db->where('state', 1);
        $this->db->order_by("lastname", "asc");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return null;
        }
    }
}