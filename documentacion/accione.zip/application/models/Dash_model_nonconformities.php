<?php

class Dash_model_nonconformities extends CI_Model
{
    public function getNonconfomities()
    {
    }

    public function getNonconformitie($id)
    {
        $this->db->select('nonconformities.description, nonconformities.openingdate, nonconformities.sumarycause, nonconformities.stratum_id');
        $this->db->select('origins.origin');
        $this->db->select('types.type');
        $this->db->select('departaments.departament');
        $this->db->select('roles.rol');
        $this->db->select('nonconformities_stratum.stratum');
        $this->db->from('nonconformities');
        $this->db->where('nonconformities.id', $id);
        $this->db->join('origins', 'origins.id=nonconformities.origin_id', 'inner');
        $this->db->join('types', 'types.id=nonconformities.type_id', 'inner');
        $this->db->join('departaments', 'departaments.id=nonconformities.departament_id', 'inner');
        $this->db->join('roles', 'roles.id=nonconformities.leader_id', 'inner');
        $this->db->join('nonconformities_stratum', 'nonconformities.stratum_id=nonconformities_stratum.id', 'Left');
        $query = $this->db->get();
        return $query->row_array();
    }

    public function getNonconfomitiesxCurrentUser($id)
    {
        //$this->db->select('nonconformities.id, nonconformities.origin_id, nonconformities.type_id, nonconformities.departament_id, nonconformities.leader_id, nonconformities.description, nonconformities.openingdate');
        $this->db->select('nonconformities.id, nonconformities.description, nonconformities.openingdate');
        $this->db->select('origins.origin');
        $this->db->select('types.type');
        $this->db->select('departaments.departament');
        $this->db->select('roles.rol');
        $this->db->from('nonconformities');
        $this->db->where('nonconformities.leader_id', $id);
        $this->db->join('origins', 'origins.id=nonconformities.origin_id', 'Left');
        $this->db->join('types', 'types.id=nonconformities.type_id', 'Left');
        $this->db->join('departaments', 'departaments.id=nonconformities.departament_id', 'Left');
        $this->db->join('roles', 'roles.id=nonconformities.leader_id', 'Left');
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return null;
        }
    }

    public function storeNonconformities($data)
    {
        $this->db->set('origin', $data['origin']);
        $this->db->set('type', $data['type']);
        $this->db->set('departament', $data['departament']);
        $this->db->set('leader', $data['leader']);
        $this->db->set('description', $data['description']);
        $this->db->set('openingdate', $data['openingdate']);
        $this->db->insert('nonconformities');
        return true;
    }

    public function storeCauses($id, $data)
    {
        $this->db->set('effect', $row['effect']);
        $this->db->insert('ishikawa_effect');
        $effect_id = $this->db->insert_id();

        foreach($data as $row){
            $this->db->set('specie_id', $row['specie_id']);
            $this->db->set('cause', $row['cause']);
            $this->db->set('effect_id', $effect_id);
            $this->db->insert('ishikawa_causes');
            $cause_id = $this->db->insert_id();

            $this->db->set('why1', $row['why1']);
            $this->db->set('why2', $row['why2']);
            $this->db->set('why3', $row['why3']);
            $this->db->set('why4', $row['why4']);
            $this->db->set('why5', $row['why5']);
            $this->db->set('conclusion', $row['conclusion']);
            $this->db->set('cause_id', $cause_id);
            $this->db->insert('ishikawa_why');         
        }
    }

    public function updateNonconformities($data, $id)
    {
    }

    public function destroyNonconformities($data)
    {
    }
}
