<?php

class Dash_model_credentials extends CI_Model
{
    public function login($email, $password)
    {
        //Realizamos una consulta para traer los datos de la tabla usuarios
        $this->db->select('id, name, lastname, rol_id');
        $this->db->from('users');
        $this->db->where('email', $email);
        $this->db->where('password', md5($password));
        $this->db->where('state', 1);
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            //return $query->row();
            return $query->row_array();
        }else{
            return null;
        }
    }
}
