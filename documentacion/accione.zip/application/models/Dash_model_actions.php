<?php

class Dash_model_actions extends CI_Model
{

    public function getActionsxCurrentUser($id)
    {
        $this->db->select('actions.id, actions.action, actions.type_id, actions.responsible_id, actions.deadline, actions.observation, actions.nonconformitie_id');
        $this->db->select('users.name, users.lastname');
        $this->db->select('types.type');
        $this->db->from('actions');
        $this->db->where('implemented', 0);
        $this->db->where('responsible_id', $id);
        $this->db->join('types', 'types.id=actions.type_id', 'Left');
        $this->db->join('users', 'users.id=actions.responsible_id', 'Left');
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return null;
        }
    }

    public function getAction($id)
    {
        $this->db->select('actions.id, actions.action, actions.type_id, actions.responsible_id, actions.deadline, actions.observation');
        $this->db->select('users.name, users.lastname');
        $this->db->select('types.type');
        $this->db->from('actions');
        $this->db->where('implemented', 0);
        $this->db->where('actions.id', $id);
        $this->db->join('types', 'types.id=actions.type_id', 'Left');
        $this->db->join('users', 'users.id=actions.responsible_id', 'Left');
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->row_array();
        } else {
            return null;
        }
    }

    public function storeAction($id, $data)
    {
        $this->db->set('action', $data['action']);
        $this->db->set('type_id', $data['type_id']);
        $this->db->set('responsible_id', $data['responsible_id']);
        $this->db->set('deadline', $data['deadline']);
        $this->db->set('observation', $data['observation']);
        $this->db->set('nonconformitie_id', $id);
        $this->db->insert('actions');
        return true;
    }

    public function updateOrigin($data, $id)
    {
        /*
        $this->db->set('origin', $data['origin']);        
        $this->db->where('state', 1);
        $this->db->where('id', $id);
        $this->db->update('origins');
        return true;
        */
    }

    public function destroyOrigin($data)
    {
        /*
        $this->db->set('state', 0);
        $this->db->where('id', $data);
        $this->db->update('origins');
        return true;
        */
    }
}
