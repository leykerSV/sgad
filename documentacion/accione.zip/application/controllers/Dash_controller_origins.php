<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dash_controller_origins extends CI_Controller
{
    public function index()
    {
        if (isset($_SESSION['id'])) {            
            $this->view_origins();
        } else {
            redirect('Dash_controller_users', "location");
        }
    }

    public function create()
    {
        if (isset($_SESSION['id'])) {
            $this->view_create_store();
        } else {
            redirect('Dash_controller_users', "location");
        }
    }

    public function store()
    {
        if (isset($_SESSION['id'])) {
            $datastore = $this->Dash_model_origins->storeOrigin($_POST);
            if (isset($datastore)) {
                $data['messagetrue'] = 'Origen creado existosmente';
            } else {
                $data['messagefalse'] = 'Error al crear Origen';
            }
            $this->view_create_store($data);
        } else {
            redirect('Dash_controller_users', "location");
        }
    }

    public function edit()
    {
        if (isset($_SESSION['id'])) {
            $this->view_edit_update();
        } else {
            redirect('Dash_controller_users', "location");
        }
    }

    public function update()
    {
        if (isset($_SESSION['id'])) {
            $dataupdate = $this->Dash_model_origins->updateOrigin($_POST, $_GET['id']);
            if(isset($dataupdate)){
                $data['messagetrue']= 'Origen editado exitosamente';
            }else{
                $data['messagefalse']= 'Error al editar Origen';
            }
            $this->view_edit_update($data);
        } else {
            redirect('Dash_controller_users', "location");
        }
    }

    public function destroy()
    {
        if (isset($_SESSION['id'])) {
            $datadestroy = $this->Dash_model_origins->destroyOrigin($_GET['id']);
            if(isset($datadestroy)){
                //$data['messagetrue']= 'Origen eliminado exitosamente';
            }else{
                //$data['messagefalse']= 'Error al Eliminar Origen';
            }
            $this->view_origins();
        } else {
            redirect('Dash_controller_users', "location");
        }
    }

    public function view_origins($data = null)
    {
        $data['origins'] = $this->Dash_model_origins->getOrigins();
        $this->load->view('include/Dash_view_header');
        $this->load->view('origins/Dash_view_origins', $data);
        $this->load->view('include/Dash_view_footer');
    }

    public function view_create_store($data = null)
    {
        $this->load->view('include/Dash_view_header');
        $this->load->view('origins/Dash_view_origins_create_store', $data);
        $this->load->view('include/Dash_view_footer');
    }

    public function view_edit_update($data = null)
    {
        $data['dataform'] = $this->Dash_model_origins->getOrigin($_GET['id']);
        $this->load->view('include/Dash_view_header');
        $this->load->view('origins/Dash_view_origins_edit_update', $data);
        $this->load->view('include/Dash_view_footer');
    }
}
