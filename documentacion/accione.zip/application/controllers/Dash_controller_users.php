<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dash_controller_users extends CI_Controller
{
    public function index()
    {
        if (isset($_SESSION['id'])) {
            $data['users'] = $this->Dash_model_users->getUsers();
            $this->load->view('include/Dash_view_header');
            $this->load->view('users/Dash_view_users', $data);
            $this->load->view('include/Dash_view_footer');
        } else {
            redirect('Dash_controller_credentials', "location");
        }
    }

    public function create()
    {
        if (isset($_SESSION['id'])) {
            $this->view_create_edit();
        } else {
            redirect('Dash_controller_credentials', "location");
        }
    }

    public function store()
    {
        if (isset($_SESSION['id'])) {
            //Falta validad que el formulario no este vacio y sean datos correctos
            $datastore = $this->Dash_model_users->storeUser($_POST);
            if (isset($datastore)) {
                $data['messagetrue'] = 'Usuario creado existosmente';
            } else {
                $data['messagefalse'] = 'Error al crear usuario';
            }            
            $this->view_create_edit($data);
        } else {
            redirect('Dash_controller_credentials', "location");
        }
    }

    public function edit()
    {
        if (isset($_SESSION['id'])) {
            $data['values'] = $this->Dash_model_users->getUser($_GET['id']);            
            $this->view_create_edit($data);
        } else {
            redirect('Dash_controller_credentials', "location");
        }
    }

    public function update()
    {
        if (isset($_SESSION['id'])) {
            $dataupdate = $this->Dash_model_users->updateUser($_POST, $_GET['id']);
            if (isset($dataupdate)) {
                $data['messagetrue'] = 'Usuario editado existosmente';
            } else {
                $data['messagefalse'] = 'Error al editar usuario';
            } 
            $this->view_create_edit($data);
        } else {
            redirect('Dash_controller_credentials', "location");
        }
    }

    public function destroy()
    {
        if (isset($_SESSION['id'])) {
            //$iduser = $this->input->get('id');//Otra manera de obtener el id
            $data = $this->Dash_model_users->destroyUser($_GET['id']);
            redirect('Dash_controller_users', "location");
        } else {
            redirect('Dash_controller_credentials', "location");
        }
    }    

    public function view_create_edit($data = null){
        $data['rolusers'] = $this->Dash_model_users->getRolesUsers();
        $this->load->view('include/Dash_view_header');
        $this->load->view('users/Dash_view_users_create_edit', $data);
        $this->load->view('include/Dash_view_footer');
    }
}
