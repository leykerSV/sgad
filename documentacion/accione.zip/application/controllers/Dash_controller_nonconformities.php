<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dash_controller_nonconformities extends CI_Controller
{

    public function index()
    {

    }

    public function showxCurrentUser()
    {
        if (isset($_SESSION['id'])) {
            $data['nonconformities'] = $this->Dash_model_nonconformities->getNonconfomitiesxCurrentUser($_SESSION['id']);
            $this->load->view('include/Dash_view_header');
            $this->load->view('nonconformities/Dash_view_nonconformities_showx_currentuser', $data);
            $this->load->view('include/Dash_view_footer');
        } else {
            redirect('Dash_controller_credentials', "location");
        }
    }

    public function create()
    {
        if (isset($_SESSION['id'])) {
            $this->view_create_store();
        } else {
            redirect('Dash_controller_credentials', "location");
        }
    }

    public function controllerCause()
    {

    }

    public function createCauses()
    {
        if (isset($_SESSION['id'])) {
            $data['dataform'] = $this->Dash_model_nonconformities->getNonconformitie($_GET['id']);
            $this->load->view('include/Dash_view_header');
            $this->load->view('nonconformities/Dash_view_nonconformities_create_causes', $data);
            $this->load->view('include/Dash_view_footer');
        } else {
            redirect('Dash_controller_credentials', "location");
        }
    }

    public function storeCauses()
    {
        if (isset($_SESSION['id'])) {
            /*
            if ($_POST['stratum']==1){

            }else{
                if ($_POST['stratum']==){

                }else{
                    
                }
            }
            */
            //$data['dataform'] = $this->Dash_model_nonconformities->storeCauses($_GET['id'], $_POST);
            redirect('Dash_controller_actions/create?id='.$_GET['id'], "location");
        } else {
            redirect('Dash_controller_credentials', "location");
        }
    }

    public function store()
    {
        if (isset($_SESSION['id'])) {
            $datastore = $this->Dash_model_nonconformities->storeNonconformities($_POST);
            if (isset($datastore)) {
                $data['messagetrue'] = 'No conformidad creada existosmente';
            } else {
                $data['messagefalse'] = 'Error al crear No conformidad';
            }
            $this->view_create_store($data);
        } else {
            redirect('Dash_controller_credentials', "location");
        }
    }

    public function edit()
    {
        if (isset($_SESSION['id'])) {
            $data['dataform'] = $this->Dash_model_nonconformities->getNonconformitie($_GET['id']);
            $this->view_edit_update($data);
        } else {
            redirect('Dash_controller_credentials', "location");
        }
    }

    public function view_create_store($data = null)
    {
        $data['departaments'] = $this->Dash_model_useful->getDepartaments();
        $data['types'] = $this->Dash_model_useful->getTypes();
        $data['origins'] = $this->Dash_model_origins->getOrigins();
        $data['leaders'] = $this->Dash_model_users->getUsersxLeaders();
        $this->load->view('include/Dash_view_header');
        $this->load->view('nonconformities/Dash_view_nonconformities_create_store', $data);
        $this->load->view('include/Dash_view_footer');
    }

    public function view_edit_update($data = null)
    {
        $data['departaments'] = $this->Dash_model_useful->getDepartaments();
        $data['types'] = $this->Dash_model_useful->getTypes();
        $data['origins'] = $this->Dash_model_origins->getOrigins();
        $data['leaders'] = $this->Dash_model_users->getUsersxLeaders();
        $this->load->view('include/Dash_view_header');
        $this->load->view('nonconformities/Dash_view_nonconformities_edit_update', $data);
        $this->load->view('include/Dash_view_footer');
    }
}
