  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
      <br>
      <!-- Main content -->
      <section class="content">
          <div class="container-fluid">
              <div class="row">
                  <!-- left column -->
                  <div class="col-md-6">
                      <div class="card card-primary">
                          <div class="card-header">
                              <h3 class="card-title">Crear Acciones</h3>
                          </div>
                          <form action="<?php echo base_url() ?>Dash_controller_actions/store?id=<?php echo $_GET['id']?>" method="post">
                              <div class="card-body">
                                  <div class="form-group">
                                      <input type="text" class="form-control" placeholder="Acción" name="action">
                                  </div>
                                  <div class="form-group">
                                      <select class="form-control" name="type_id">
                                          <option value="0">Tipo</option>
                                          <?php 
                                          foreach ($types as $row) {
                                            echo '<option value="' . $row['id'] . '">' . $row['type'] . '</option>';
                                          }
                                          ?>
                                      </select>
                                  </div>
                                  <div class="form-group">
                                      <select class="form-control" name="responsible_id">
                                          <option value="0">Responsable</option>
                                          <?php
                                          foreach ($responsibles as $row) {
                                            echo '<option value="' . $row['id'] . '">' . $row['lastname'] . ' ' . $row['name'] . '</option>';
                                          }
                                          ?>
                                      </select>
                                  </div>
                                  <div class="form-group">
                                      <div class="input-group">
                                          <input type="text" class="form-control" name="deadline"
                                              data-inputmask-alias="datetime" data-inputmask-inputformat="dd/mm/yyyy"
                                              data-mask placeholder="Fecha Limite">
                                      </div>
                                  </div>
                                  <div class="form-group">
                                      <textarea class="form-control" name="observation" rows="3"
                                          placeholder="Observaciones"></textarea>
                                  </div>
                              </div>
                              <div class="card-footer">
                                  <button type="submit" class="btn btn-primary">Guardar</button>
                                  <?php
                                if (isset($messagetrue)) {
                                  echo '<p class="text-success">' . $messagetrue . '</p>';
                                }
                                if (isset($messagefalse)) {
                                    echo '<p class="text-danger">' . $messagefalse . '</p>';
                                }
                                ?>
                              </div>
                          </form>
                      </div>
                  </div>

                  <!-- right colum -->
                  <div class="col-md-6">
                  </div>
              </div>
              <!-- /.row -->
          </div><!-- /.container-fluid -->
      </section>
      <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->