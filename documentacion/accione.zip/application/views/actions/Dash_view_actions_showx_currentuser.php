<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Main content -->
    <section class="content">

        <!-- Default box -->
        <div class="card card-primary">
            <div class="card-header">
                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip"
                        title="Collapse">
                        <i class="fas fa-minus"></i></button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip"
                        title="Remove">
                        <i class="fas fa-times"></i></button>
                </div>
            </div>
            <div class="card-body p-0">
                <table class="table table-striped projects">
                    <thead>
                        <tr>
                            <th>
                                #
                            </th>
                            <th>
                                Acción
                            </th>
                            <th>
                                Tipo
                            </th>
                            <th>
                                Lider
                            </th>
                            <th>
                                Fecha Limite
                            </th>
                            <th>
                                Estado Implementación
                            </th>
                            <th>
                                Observación
                            </th>
                            <th>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if(isset($actions)){
                            foreach($actions as $row){
                            echo '<tr>';
                            echo '<td>'. $row['id'] .'</td>';
                            echo '<td>'. $row['action'] .'</td>';
                            echo '<td>'. $row['type'] .'</td>';
                            echo '<td>'. $row['name'] . ' ' . $row['lastname'] .'</td>';
                            echo '<td>'. $row['deadline'] .'</td>';
                            echo '<td>'. '<span class="badge badge badge-danger">Abierta</span>' .'</td>';
                            echo '<td>'. $row['observation'] .'</td>';
                            echo '<td>';
                            echo '
                            <a class="btn btn-primary btn-sm" href="'.base_url().'Dash_controller_actions/edit?id='.$row['id'].'">
                                <i class="nav-icon fas fa-pencil-alt"></i>&nbsp;&nbsp;Completar Acción
                            </a>';
                            echo '</td>';
                            echo '</tr>';
                            }
                        }                        
                        ?>
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->

    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->