<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Main content -->
    <section class="content">

        <!-- Default box -->
        <div class="card card-primary">
            <div class="card-header">
                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip"
                        title="Collapse">
                        <i class="fas fa-minus"></i></button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip"
                        title="Remove">
                        <i class="fas fa-times"></i></button>
                </div>
            </div>
            <div class="card-body p-0">
                <table class="table table-striped projects">
                    <thead>
                        <tr>
                            <th>
                                #
                            </th>
                            <th>
                                Nombre
                            </th>
                            <th>
                                Apellido
                            </th>
                            <th>
                                Correo
                            </th>
                            <th>
                                Rol
                            </th>
                            <th>
                                <a class="btn btn-warning btn-sm text-white"
                                    href="<?php echo base_url()?>Dash_controller_users/create">
                                    <i class="fas fa-plus-square"></i>&nbsp;&nbsp;Crear Nuevo
                                </a>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach($users as $row)
                        {
                            echo '<tr>';
                            echo '<td>'. $row['id'] .'</td>';
                            echo '<td>'. $row['name'] .'</td>';
                            echo '<td>'. $row['lastname'] .'</td>';
                            echo '<td>'. $row['email'] .'</td>';
                            echo '<td>'. $row['rol'] .'</td>';
                            echo '<td>';
                            echo '
                            <a class="btn btn-success btn-sm" href="'.base_url().'Dash_controller_users/edit?id='.$row['id'].'">
                                <i class="nav-icon fas fa-pencil-alt"></i>&nbsp;&nbsp;Modificar
                            </a>';
                            echo '
                            <a class="btn btn-danger btn-sm" href="'.base_url().'Dash_controller_users/destroy?id='.$row['id'].'">
                                <i class="nav-icon fas fa-trash"></i>&nbsp;&nbsp;Eliminar
                            </a>';
                            echo '</td>';
                            echo '</tr>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->

    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->