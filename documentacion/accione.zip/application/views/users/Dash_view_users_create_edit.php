  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
      <br>
      <!-- Main content -->
      <section class="content">
          <div class="container-fluid">
              <div class="row">
                  <!-- left column -->
                  <div class="col-md-6">
                      <div class="card card-primary">
                          <div class="card-header">
                              <h3 class="card-title"><?php if(isset($values)){ echo 'Editar ';}else{echo 'Crear ';}?>Usuario</h3>
                          </div>
                          <form action="<?php echo base_url() ?>Dash_controller_users/<?php if(isset($values)){ echo 'update?id='.$_GET['id'];}else{echo 'store';}?>" method="post">
                              <div class="card-body">
                                  <div class="form-group">
                                      <div class="input-group">
                                          <input class="form-control" <?php if (isset($values)) {echo 'value="' . $values['name'] . '"';}?> name="name" type="text" placeholder="Nombre">
                                      </div>
                                  </div>
                                  <div class="form-group">
                                      <div class="input-group">
                                          <input class="form-control" <?php if (isset($values)) {echo 'value="' . $values['lastname'] . '"';}?> name="lastname" type="text"
                                              placeholder="Apellido">
                                      </div>
                                  </div>
                                  <div class="form-group">
                                      <input class="form-control" <?php if (isset($values)) {echo 'value="' . $values['email'] . '"';}?> name="email" type="email" placeholder="Email">
                                  </div>
                                  <div class="form-group">
                                      <input class="form-control" name="password" type="password"
                                          placeholder="Contraseña">
                                  </div>
                                  <!--
                                  <div class="form-group">
                                      <select class="select2 w-100" multiple="multiple" data-placeholder="Rol">

                                      </select>
                                  </div>
                                  -->
                                  <div class="form-group">
                                      <select class="form-control" name="rol_id">
                                          <option value="0">Rol</option>
                                          <?php
foreach ($rolusers as $row) {
    if (isset($values)) {
        if ($values['rol'] == $row['id']) {
            echo '<option value="' . $row['id'] . '" selected>' . $row['rol'] . '</option>';
        } else {
            echo '<option value="' . $row['id'] . '">' . $row['rol'] . '</option>';
        }
    } else {
        echo '<option value="' . $row['id'] . '">' . $row['rol'] . '</option>';
    }
}
?>
                                      </select>
                                  </div>
                                  <?php
if (isset($messagetrue)) {
    echo '<p class="text-success">' . $messagetrue . '</p>';
}
if (isset($messagefalse)) {
    echo '<p class="text-danger">' . $messagefalse . '</p>';
}
?>
                              </div>
                              <div class="card-footer">
                                  <button type="submit" class="btn btn-primary">Guardar</button>
                              </div>
                          </form>
                      </div>
                  </div>

                  <!-- right colum -->
                  <div class="col-md-6">
                  </div>
              </div>
              <!-- /.row -->
          </div><!-- /.container-fluid -->
      </section>
      <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->